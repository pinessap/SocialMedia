<!DOCTYPE html>
<?php
    $title = 'New Post'; 
?>
    <body> 
        <?php include "navbar.php" ?>
        <div class="container">
            <div class="row space-around">
                <a href="php/newPost.php" class="submit-btn">New Post</a>
                <a href="php/viewPosts.php" class="submit-btn">View Posts</a>
            </div>
        </div>
    </body>
</html>