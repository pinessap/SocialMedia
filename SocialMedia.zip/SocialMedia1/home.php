  <html> 
    <?php require 'navbar.php';?> 
 
 </html> 